export * from './compiled-types/src/app/editor/page';
export { default } from './compiled-types/src/app/editor/page';