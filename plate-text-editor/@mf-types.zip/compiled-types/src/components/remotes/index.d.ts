declare const instance: import("@module-federation/runtime-core").ModuleFederation | null;
export { instance };
