export declare const AutoformatKit: import("platejs").SlatePlugin<import("@platejs/autoformat").AutoformatConfig>[];
