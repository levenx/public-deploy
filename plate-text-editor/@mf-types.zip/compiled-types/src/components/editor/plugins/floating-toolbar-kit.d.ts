export declare const FloatingToolbarKit: import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"floating-toolbar", {}, {}, {}, {}>>[];
