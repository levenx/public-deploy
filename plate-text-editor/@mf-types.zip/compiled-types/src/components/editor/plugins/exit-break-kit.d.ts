export declare const ExitBreakKit: import("platejs").SlatePlugin<import("platejs").PluginConfig<"exitBreak", {}, {}, Record<"exitBreak", {
    insert: (options: Omit<import("platejs").InsertExitBreakOptions, "reverse">) => true | undefined;
    insertBefore: (options: Omit<import("platejs").InsertExitBreakOptions, "reverse">) => true | undefined;
}>, {}>>[];
