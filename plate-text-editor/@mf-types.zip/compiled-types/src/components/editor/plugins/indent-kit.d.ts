export declare const IndentKit: import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"indent", {
    indentMax?: number;
    offset?: number;
    unit?: string;
}, {}, {}, {}>>[];
