export declare const BaseAlignKit: import("platejs").SlatePlugin<import("platejs").PluginConfig<"textAlign", {}, {}, Record<"textAlign", {
    setNodes: (value: import("@platejs/basic-styles").Alignment, setNodesOptions?: import("platejs").SetNodesOptions | undefined) => void;
}>, {}>>[];
