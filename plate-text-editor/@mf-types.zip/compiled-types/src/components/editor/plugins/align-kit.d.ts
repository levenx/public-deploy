export declare const AlignKit: import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"textAlign", {}, {}, Record<"textAlign", {
    setNodes: (value: import("@platejs/basic-styles").Alignment, setNodesOptions?: import("platejs").SetNodesOptions | undefined) => void;
}>, {}>>[];
