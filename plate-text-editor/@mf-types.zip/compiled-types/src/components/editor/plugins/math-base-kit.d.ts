export declare const BaseMathKit: (import("platejs").SlatePlugin<import("platejs").PluginConfig<"inline_equation", {}, {}, {
    insert: {
        inlineEquation: (texExpression?: string | undefined, options?: import("platejs").InsertNodesOptions | undefined) => void;
    };
}, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"equation", {}, {}, {
    insert: {
        equation: (options?: import("platejs").InsertNodesOptions | undefined) => void;
    };
}, {}>>)[];
