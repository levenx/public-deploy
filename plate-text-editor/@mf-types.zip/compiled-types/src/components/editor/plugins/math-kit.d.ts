export declare const MathKit: (import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"inline_equation", {}, {}, {
    insert: {
        inlineEquation: (texExpression?: string | undefined, options?: import("platejs").InsertNodesOptions | undefined) => void;
    };
}, {}>> | import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"equation", {}, {}, {
    insert: {
        equation: (options?: import("platejs").InsertNodesOptions | undefined) => void;
    };
}, {}>>)[];
