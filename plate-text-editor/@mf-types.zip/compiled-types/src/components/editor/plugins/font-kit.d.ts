export declare const FontKit: (import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"fontSize", {}, {}, Record<"fontSize", {
    addMark: (value: string) => void;
}>, {}>> | import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"color", {}, {}, Record<"color", {
    addMark: (value: string) => void;
}>, {}>> | import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"backgroundColor", {}, {}, Record<"backgroundColor", {
    addMark: (value: string) => void;
}>, {}>> | import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"fontFamily", {}, {}, Record<"fontFamily", {
    addMark: (value: string) => void;
}>, {}>>)[];
