export declare const BaseListKit: (import("platejs").SlatePlugin<import("@platejs/indent").IndentConfig> | import("platejs").SlatePlugin<import("@platejs/list").BaseListConfig>)[];
