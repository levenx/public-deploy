export declare const BaseBasicMarksKit: (import("platejs").SlatePlugin<import("platejs").PluginConfig<"bold", {}, {}, Record<"bold", {
    toggle: () => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"italic", {}, {}, Record<"italic", {
    toggle: () => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"underline", {}, {}, Record<"underline", {
    toggle: () => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"code", {}, {}, Record<"code", {
    toggle: () => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"strikethrough", {}, {}, Record<"strikethrough", {
    toggle: () => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"subscript", {}, {}, Record<"subscript", {
    toggle: () => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"superscript", {}, {}, Record<"superscript", {
    toggle: () => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"highlight", {}, {}, Record<"highlight", {
    toggle: () => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"kbd", {}, {}, Record<"kbd", {
    toggle: () => void;
}>, {}>>)[];
