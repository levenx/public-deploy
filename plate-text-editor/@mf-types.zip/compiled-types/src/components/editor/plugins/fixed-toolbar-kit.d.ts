export declare const FixedToolbarKit: import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"fixed-toolbar", {}, {}, {}, {}>>[];
