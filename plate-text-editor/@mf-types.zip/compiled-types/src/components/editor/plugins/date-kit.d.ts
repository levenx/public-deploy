export declare const DateKit: import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"date", {}, {}, {
    insert: {
        date: (args_0?: ({
            date?: string;
        } & {
            batchDirty?: boolean;
            hanging?: boolean;
            nextBlock?: boolean;
            removeEmpty?: import("platejs").QueryNodeOptions | boolean;
            select?: boolean;
        } & {
            id?: boolean | string;
            block?: boolean;
            empty?: boolean;
            match?: import("platejs").Predicate<import("platejs").NodeIn<import("platejs").Value>> | undefined;
            text?: boolean;
        } & import("platejs").QueryAt & import("platejs").QueryMode & import("platejs").QueryVoids) | undefined) => void;
    };
}, {}>>[];
