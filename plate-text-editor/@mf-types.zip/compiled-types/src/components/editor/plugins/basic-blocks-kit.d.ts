export declare const BasicBlocksKit: (import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"p", {}, {}, {}, {}>> | import("platejs/react").PlatePlugin<import("platejs").PluginConfig<any, {}, {}, Record<any, {
    toggle: () => void;
}>, {}>> | import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"blockquote", {}, {}, Record<"blockquote", {
    toggle: () => void;
}>, {}>> | import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"hr", {}, {}, {}, {}>>)[];
