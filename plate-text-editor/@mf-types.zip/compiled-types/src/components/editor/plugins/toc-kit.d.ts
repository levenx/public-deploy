export declare const TocKit: import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"toc", {
    isScroll: boolean;
    topOffset: number;
    queryHeading?: (editor: import("platejs").SlateEditor) => import("@platejs/toc").Heading[];
}, {}, {}, {}>>[];
