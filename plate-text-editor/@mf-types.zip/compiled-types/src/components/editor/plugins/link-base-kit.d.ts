export declare const BaseLinkKit: import("platejs").SlatePlugin<import("@platejs/link").BaseLinkConfig>[];
