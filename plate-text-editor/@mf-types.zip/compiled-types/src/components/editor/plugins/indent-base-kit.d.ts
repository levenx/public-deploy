export declare const BaseIndentKit: import("platejs").SlatePlugin<import("@platejs/indent").IndentConfig>[];
