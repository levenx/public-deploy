export declare const BaseFontKit: (import("platejs").SlatePlugin<import("platejs").PluginConfig<"color", {}, {}, Record<"color", {
    addMark: (value: string) => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"backgroundColor", {}, {}, Record<"backgroundColor", {
    addMark: (value: string) => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"fontSize", {}, {}, Record<"fontSize", {
    addMark: (value: string) => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"fontFamily", {}, {}, Record<"fontFamily", {
    addMark: (value: string) => void;
}>, {}>>)[];
