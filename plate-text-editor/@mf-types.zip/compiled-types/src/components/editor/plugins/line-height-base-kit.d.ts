export declare const BaseLineHeightKit: import("platejs").SlatePlugin<import("platejs").PluginConfig<"lineHeight", {}, {}, Record<"lineHeight", {
    setNodes: (value: number, setNodesOptions?: import("platejs").SetNodesOptions | undefined) => void;
}>, {}>>[];
