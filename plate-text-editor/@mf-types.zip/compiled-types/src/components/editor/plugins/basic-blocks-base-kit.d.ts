export declare const BaseBasicBlocksKit: (import("platejs").SlatePlugin<import("platejs").PluginConfig<"p", {}, {}, {}, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<any, {}, {}, Record<any, {
    toggle: () => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"blockquote", {}, {}, Record<"blockquote", {
    toggle: () => void;
}>, {}>> | import("platejs").SlatePlugin<import("platejs").PluginConfig<"hr", {}, {}, {}, {}>>)[];
