export declare const LineHeightKit: import("platejs/react").PlatePlugin<import("platejs").PluginConfig<"lineHeight", {}, {}, Record<"lineHeight", {
    setNodes: (value: number, setNodesOptions?: import("platejs").SetNodesOptions | undefined) => void;
}>, {}>>[];
