export declare const BaseTocKit: import("platejs").SlatePlugin<import("@platejs/toc").TocConfig>[];
