type Model = {
    label: string;
    value: string;
};
export declare const models: Model[];
export declare function SettingsDialog(): import("react/jsx-runtime").JSX.Element;
export {};
