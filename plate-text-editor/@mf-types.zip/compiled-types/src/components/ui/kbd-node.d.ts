import type { PlateLeafProps } from 'platejs/react';
export declare function KbdLeaf(props: PlateLeafProps): import("react/jsx-runtime").JSX.Element;
