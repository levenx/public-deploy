import { Toolbar } from './toolbar';
export declare function FixedToolbar(props: React.ComponentProps<typeof Toolbar>): import("react/jsx-runtime").JSX.Element;
