import type { TSuggestionText } from 'platejs';
import type { SlateLeafProps } from 'platejs/static';
export declare function SuggestionLeafStatic(props: SlateLeafProps<TSuggestionText>): import("react/jsx-runtime").JSX.Element;
