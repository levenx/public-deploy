export declare function AIMenu(): import("react/jsx-runtime").JSX.Element | null;
export declare const AIMenuItems: ({ input, setInput, setValue, }: {
    input: string;
    setInput: (value: string) => void;
    setValue: (value: string) => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare function AILoadingBar(): import("react/jsx-runtime").JSX.Element | null;
