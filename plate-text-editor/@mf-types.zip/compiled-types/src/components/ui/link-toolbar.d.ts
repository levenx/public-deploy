import { type LinkFloatingToolbarState } from '@platejs/link/react';
export declare function LinkFloatingToolbar({ state, }: {
    state?: LinkFloatingToolbarState;
}): import("react/jsx-runtime").JSX.Element | null;
