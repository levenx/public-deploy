import type { SlateElementProps } from 'platejs/static';
export declare function ToggleElementStatic(props: SlateElementProps): import("react/jsx-runtime").JSX.Element;
