import type { SlateLeafProps } from 'platejs/static';
export declare function CodeLeafStatic(props: SlateLeafProps): import("react/jsx-runtime").JSX.Element;
