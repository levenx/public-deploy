export declare function FloatingToolbarButtons(): import("react/jsx-runtime").JSX.Element;
