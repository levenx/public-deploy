export declare function MediaPreviewDialog(): import("react/jsx-runtime").JSX.Element;
