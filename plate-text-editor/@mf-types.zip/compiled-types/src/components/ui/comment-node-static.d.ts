import type { TCommentText } from 'platejs';
import type { SlateLeafProps } from 'platejs/static';
export declare function CommentLeafStatic(props: SlateLeafProps<TCommentText>): import("react/jsx-runtime").JSX.Element;
