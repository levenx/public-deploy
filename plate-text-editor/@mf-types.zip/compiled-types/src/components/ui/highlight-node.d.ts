import type { PlateLeafProps } from 'platejs/react';
export declare function HighlightLeaf(props: PlateLeafProps): import("react/jsx-runtime").JSX.Element;
