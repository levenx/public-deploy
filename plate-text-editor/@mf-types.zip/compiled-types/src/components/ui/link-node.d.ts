import type { TLinkElement } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
export declare function LinkElement(props: PlateElementProps<TLinkElement>): import("react/jsx-runtime").JSX.Element;
