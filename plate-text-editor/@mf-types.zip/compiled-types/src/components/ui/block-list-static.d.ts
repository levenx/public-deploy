import type { RenderStaticNodeWrapper } from 'platejs';
export declare const BlockListStatic: RenderStaticNodeWrapper;
