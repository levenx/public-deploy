import { type SlateElementProps } from 'platejs/static';
export declare function BlockquoteElementStatic(props: SlateElementProps): import("react/jsx-runtime").JSX.Element;
