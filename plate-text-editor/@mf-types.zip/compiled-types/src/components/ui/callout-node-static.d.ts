import type { SlateElementProps } from 'platejs/static';
export declare function CalloutElementStatic({ children, className, ...props }: SlateElementProps): import("react/jsx-runtime").JSX.Element;
