import type { TFileElement } from 'platejs';
import type { SlateElementProps } from 'platejs/static';
export declare function FileElementStatic(props: SlateElementProps<TFileElement>): import("react/jsx-runtime").JSX.Element;
