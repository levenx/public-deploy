export declare function CursorOverlay(): import("react/jsx-runtime").JSX.Element;
