import type * as React from 'react';
import { ToolbarButton } from './toolbar';
export declare function InlineEquationToolbarButton(props: React.ComponentProps<typeof ToolbarButton>): import("react/jsx-runtime").JSX.Element;
