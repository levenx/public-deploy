import { type TComboboxInputElement } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
export declare function SlashInputElement(props: PlateElementProps<TComboboxInputElement>): import("react/jsx-runtime").JSX.Element;
