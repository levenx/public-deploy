import type { TAudioElement } from 'platejs';
import type { SlateElementProps } from 'platejs/static';
export declare function AudioElementStatic(props: SlateElementProps<TAudioElement>): import("react/jsx-runtime").JSX.Element;
