import type { TColumnElement } from 'platejs';
import type { SlateElementProps } from 'platejs/static';
export declare function ColumnElementStatic(props: SlateElementProps<TColumnElement>): import("react/jsx-runtime").JSX.Element;
export declare function ColumnGroupElementStatic(props: SlateElementProps): import("react/jsx-runtime").JSX.Element;
