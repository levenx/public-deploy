import type { SlateElementProps } from 'platejs/static';
export declare function HrElementStatic(props: SlateElementProps): import("react/jsx-runtime").JSX.Element;
