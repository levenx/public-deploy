import type { TDateElement } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
export declare function DateElement(props: PlateElementProps<TDateElement>): import("react/jsx-runtime").JSX.Element;
