export declare function CommentToolbarButton(): import("react/jsx-runtime").JSX.Element;
