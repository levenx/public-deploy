import type { TCommentText } from 'platejs';
import type { PlateLeafProps } from 'platejs/react';
export declare function CommentLeaf(props: PlateLeafProps<TCommentText>): import("react/jsx-runtime").JSX.Element;
