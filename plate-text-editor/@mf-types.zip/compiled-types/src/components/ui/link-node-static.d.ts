import type { TLinkElement } from 'platejs';
import type { SlateElementProps } from 'platejs/static';
export declare function LinkElementStatic(props: SlateElementProps<TLinkElement>): import("react/jsx-runtime").JSX.Element;
