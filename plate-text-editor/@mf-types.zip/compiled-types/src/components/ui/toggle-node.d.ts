import type { PlateElementProps } from 'platejs/react';
export declare function ToggleElement(props: PlateElementProps): import("react/jsx-runtime").JSX.Element;
