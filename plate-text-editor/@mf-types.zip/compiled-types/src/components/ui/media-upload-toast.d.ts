export declare function MediaUploadToast(): null;
