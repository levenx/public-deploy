import { type RenderNodeWrapper } from 'platejs/react';
export declare const BlockList: RenderNodeWrapper;
