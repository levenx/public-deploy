import * as React from 'react';
import { ToolbarButton } from './toolbar';
export declare function BulletedListToolbarButton(): import("react/jsx-runtime").JSX.Element;
export declare function NumberedListToolbarButton(): import("react/jsx-runtime").JSX.Element;
export declare function TodoListToolbarButton(props: React.ComponentProps<typeof ToolbarButton>): import("react/jsx-runtime").JSX.Element;
