import { type PlateElementProps, type PlateTextProps } from 'platejs/react';
export declare function AILeaf(props: PlateTextProps): import("react/jsx-runtime").JSX.Element;
export declare function AIAnchorElement(props: PlateElementProps): import("react/jsx-runtime").JSX.Element;
