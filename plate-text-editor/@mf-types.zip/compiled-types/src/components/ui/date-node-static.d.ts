import type { TDateElement } from 'platejs';
import type { SlateElementProps } from 'platejs/static';
export declare function DateElementStatic(props: SlateElementProps<TDateElement>): import("react/jsx-runtime").JSX.Element;
