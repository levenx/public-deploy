import type * as React from 'react';
import { ToolbarButton } from './toolbar';
export declare function IndentToolbarButton(props: React.ComponentProps<typeof ToolbarButton>): import("react/jsx-runtime").JSX.Element;
export declare function OutdentToolbarButton(props: React.ComponentProps<typeof ToolbarButton>): import("react/jsx-runtime").JSX.Element;
