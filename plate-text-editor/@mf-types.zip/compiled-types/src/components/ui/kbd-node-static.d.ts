import type { SlateLeafProps } from 'platejs/static';
export declare function KbdLeafStatic(props: SlateLeafProps): import("react/jsx-runtime").JSX.Element;
