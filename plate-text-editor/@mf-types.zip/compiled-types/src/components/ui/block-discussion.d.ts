import { type AnyPluginConfig } from 'platejs';
import type { RenderNodeWrapper } from 'platejs/react';
export declare const BlockDiscussion: RenderNodeWrapper<AnyPluginConfig>;
