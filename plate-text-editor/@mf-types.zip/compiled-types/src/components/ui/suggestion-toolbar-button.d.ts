export declare function SuggestionToolbarButton(): import("react/jsx-runtime").JSX.Element;
