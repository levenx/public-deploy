import * as React from 'react';
export declare const AIChatEditor: React.NamedExoticComponent<{
    content: string;
}>;
