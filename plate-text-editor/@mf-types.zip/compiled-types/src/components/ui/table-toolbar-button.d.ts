import type { DropdownMenuProps } from '@radix-ui/react-dropdown-menu';
export declare function TableToolbarButton(props: DropdownMenuProps): import("react/jsx-runtime").JSX.Element;
