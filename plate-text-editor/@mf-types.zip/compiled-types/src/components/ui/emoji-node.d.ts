import type { PlateElementProps } from 'platejs/react';
export declare function EmojiInputElement(props: PlateElementProps): import("react/jsx-runtime").JSX.Element;
