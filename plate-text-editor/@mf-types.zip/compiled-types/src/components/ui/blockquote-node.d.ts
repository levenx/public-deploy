import { type PlateElementProps } from 'platejs/react';
export declare function BlockquoteElement(props: PlateElementProps): import("react/jsx-runtime").JSX.Element;
