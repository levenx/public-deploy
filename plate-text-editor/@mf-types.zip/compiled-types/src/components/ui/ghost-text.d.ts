export declare function GhostText(): import("react/jsx-runtime").JSX.Element | null;
