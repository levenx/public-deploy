import type { PlateLeafProps } from 'platejs/react';
export declare function CodeLeaf(props: PlateLeafProps): import("react/jsx-runtime").JSX.Element;
