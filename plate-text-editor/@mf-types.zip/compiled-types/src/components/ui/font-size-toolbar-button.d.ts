export declare function FontSizeToolbarButton(): import("react/jsx-runtime").JSX.Element;
