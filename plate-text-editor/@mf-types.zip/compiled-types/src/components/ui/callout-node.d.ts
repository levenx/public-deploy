import { PlateElement } from 'platejs/react';
import type * as React from 'react';
export declare function CalloutElement({ attributes, children, className, ...props }: React.ComponentProps<typeof PlateElement>): import("react/jsx-runtime").JSX.Element;
