import type { LucideProps } from 'lucide-react';
export declare function BorderAllIcon(props: LucideProps): import("react/jsx-runtime").JSX.Element;
export declare function BorderBottomIcon(props: LucideProps): import("react/jsx-runtime").JSX.Element;
export declare function BorderLeftIcon(props: LucideProps): import("react/jsx-runtime").JSX.Element;
export declare function BorderNoneIcon(props: LucideProps): import("react/jsx-runtime").JSX.Element;
export declare function BorderRightIcon(props: LucideProps): import("react/jsx-runtime").JSX.Element;
export declare function BorderTopIcon(props: LucideProps): import("react/jsx-runtime").JSX.Element;
