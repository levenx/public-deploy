import { type PlateElementProps } from 'platejs/react';
export declare const blockSelectionVariants: (props?: ({
    active?: boolean | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export declare function BlockSelection(props: PlateElementProps): import("react/jsx-runtime").JSX.Element | null;
