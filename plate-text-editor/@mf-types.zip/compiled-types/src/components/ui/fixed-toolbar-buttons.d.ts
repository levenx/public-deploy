export declare function FixedToolbarButtons(): import("react/jsx-runtime").JSX.Element;
