import type { PlateElementProps } from 'platejs/react';
export declare function HrElement(props: PlateElementProps): import("react/jsx-runtime").JSX.Element;
