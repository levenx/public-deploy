import type { PlateElementProps } from 'platejs/react';
export declare function TocElement(props: PlateElementProps): import("react/jsx-runtime").JSX.Element;
