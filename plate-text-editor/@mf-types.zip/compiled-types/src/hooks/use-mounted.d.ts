export declare function useMounted(): boolean;
