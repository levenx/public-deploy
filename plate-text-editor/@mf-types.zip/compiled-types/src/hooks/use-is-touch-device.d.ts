export declare function useIsTouchDevice(): boolean;
