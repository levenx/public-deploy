export * from './compiled-types/components/material-picker';
export { default } from './compiled-types/components/material-picker';