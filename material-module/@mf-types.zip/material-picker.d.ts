export * from './compiled-types/modules/material-picker/index';
export { default } from './compiled-types/modules/material-picker/index';