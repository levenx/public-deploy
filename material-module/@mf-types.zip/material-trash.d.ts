export * from './compiled-types/modules/material-trash/index';
export { default } from './compiled-types/modules/material-trash/index';