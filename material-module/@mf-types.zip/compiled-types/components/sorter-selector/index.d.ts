interface SorterSelectorProps {
    value?: string[];
    onChange?: (value: string[]) => void;
}
export declare function SorterSelector(props: SorterSelectorProps): import("react/jsx-runtime").JSX.Element;
export {};
