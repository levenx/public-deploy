export type FormatProps = {
    format?: {
        width: number;
        height: number;
    };
};
export declare function FormatText({ format }: FormatProps): import("react/jsx-runtime").JSX.Element | null;
