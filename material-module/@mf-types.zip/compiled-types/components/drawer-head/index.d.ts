import { type ReactNode } from "react";
interface DrawerHeadProps {
    title: ReactNode;
    subtitle?: ReactNode;
    extra?: ReactNode;
}
export default function DrawerHead(props: DrawerHeadProps): import("react/jsx-runtime").JSX.Element;
export {};
