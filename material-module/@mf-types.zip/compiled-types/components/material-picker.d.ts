export interface MaterialDrawerProps {
    open: boolean;
    onClose: () => void;
}
export default function MaterialPicker(props: MaterialDrawerProps): import("react/jsx-runtime").JSX.Element;
