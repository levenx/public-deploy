import type { RibbonProps } from "antd/es/badge/Ribbon";
interface BadgeRibbonProps extends RibbonProps {
    visible?: boolean;
}
export declare function BadgeRibbon(props: BadgeRibbonProps): string | number | boolean | import("react/jsx-runtime").JSX.Element | Iterable<import("react").ReactNode> | null | undefined;
export {};
