interface EditTextProps {
    value?: string;
    onEdit: (value: string) => void;
}
export declare function EditText(props: EditTextProps): import("react/jsx-runtime").JSX.Element;
export {};
