export declare function formatNumberBinary(num: number): string;
