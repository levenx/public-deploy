import type { IMaterialItem } from "@/services/material";
export declare const getUrl: (item: IMaterialItem) => string;
