declare const request: import("axios").AxiosInstance;
export default request;
