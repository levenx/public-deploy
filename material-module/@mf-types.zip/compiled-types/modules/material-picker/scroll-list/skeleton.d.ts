export declare function ScrollSkeleton(): import("react/jsx-runtime").JSX.Element;
