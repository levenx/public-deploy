export declare function MaterialViews({ editItemId }: {
    editItemId: number;
}): import("react/jsx-runtime").JSX.Element;
