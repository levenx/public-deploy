import "../../index.css";
export interface MaterialPickerProps {
    repo: string;
    open: boolean;
    onClose: () => void;
}
export declare function MaterialTrash(props: MaterialPickerProps): import("react/jsx-runtime").JSX.Element;
export default function (props: MaterialPickerProps): import("react/jsx-runtime").JSX.Element;
