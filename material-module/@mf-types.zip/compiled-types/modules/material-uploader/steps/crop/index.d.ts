export declare function UploaderCropStep(): import("react/jsx-runtime").JSX.Element;
