interface TitleEditorProps {
    name: string;
    onSubmit: (name: string) => void;
    onCancel: () => void;
}
export declare function TitleEditor(props: TitleEditorProps): import("react/jsx-runtime").JSX.Element;
export {};
