export declare function UploaderSelectorStep(): import("react/jsx-runtime").JSX.Element;
