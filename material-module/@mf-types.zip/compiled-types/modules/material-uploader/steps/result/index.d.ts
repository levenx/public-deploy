export declare function UploaderResultStep(): import("react/jsx-runtime").JSX.Element;
