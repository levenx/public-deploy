interface MaterialUploaderProps {
    repo: string;
    open: boolean;
    onClose: () => void;
}
export default function MaterialUploader(props: MaterialUploaderProps): import("react/jsx-runtime").JSX.Element;
export {};
