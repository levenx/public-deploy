export * from './compiled-types/modules/material-uploader/index';
export { default } from './compiled-types/modules/material-uploader/index';